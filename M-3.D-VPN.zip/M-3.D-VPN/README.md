# DYLAN VPN

Client VPN Android (Kotlin + Jetpack Compose) pour liens **vmess / vless / trojan / shadowsocks** (noyau Xray).
Onglets : Home · Configs · Logs · More (Per-app Proxy, batterie, profils VPN système).

## Utilisation
1. Copie un lien `vless://…` / `vmess://…` / `trojan://…` / `ss://…` (un par ligne possible).
2. Onglet **Configs** → bouton **+** (importe depuis le presse-papiers) → touche la config pour la choisir.
3. Onglet **Home** → bouton power.

## Compiler
Push sur GitHub : l'action **Build DYLAN VPN** télécharge `libv2ray.aar` et produit l'APK (onglet Actions → Artifacts).
En local : mets `libv2ray.aar` dans `app/libs/` puis `gradle :app:assembleDebug`.

## Noyau
Le noyau Xray (libv2ray.aar) fournit une entrée **TUN native** : `DylanVpnService` ouvre l'interface VPN Android
et passe son descripteur à `startLoop(config, fd)`. Pas de tun2socks nécessaire.
Le débit affiché = trafic de l'app vers le serveur ; le bouton **PING** mesure le délai réel à travers le tunnel (ou TCP si déconnecté).
