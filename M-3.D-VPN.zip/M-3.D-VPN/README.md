# DYLAN VPN

Client VPN Android (Kotlin + Jetpack Compose) pour liens **vmess / vless / trojan / shadowsocks** (noyau Xray).
Onglets : Home · Configs · Logs · More (Per-app Proxy, batterie, profils VPN système).

## Utilisation
1. Copie un lien `vless://…` / `vmess://…` / `trojan://…` / `ss://…` (un par ligne possible).
2. Onglet **Configs** → bouton **+** (importe depuis le presse-papiers) → touche la config pour la choisir.
3. Onglet **Home** → bouton power.

## Compiler
Push sur GitHub : l'action **Build DYLAN VPN** télécharge `libv2ray.aar` et produit l'APK (onglet Actions → Artifacts).
En local : mets `libv2ray.aar` dans `app/libs/` puis `gradle :app:assembleDebug`.

## Brancher le noyau (à faire)
Dans `DylanVpnService.kt`, `CoreBridge.start()` : lancer Xray avec le JSON généré (SOCKS 127.0.0.1:10808),
puis relier le TUN (`tun.fd`) à ce SOCKS avec un tun2socks (ex. hev-socks5-tunnel). `stop()` arrête les deux.
Sans cette étape, l'interface et la gestion des configs fonctionnent mais le trafic n'est pas encore tunnelé.
