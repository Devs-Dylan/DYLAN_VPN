package com.dylan.vpn

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0A0C0A); private val Card = Color(0xFF101810); private val Green = Color(0xFF4ADE80)
private val Gold = Color(0xFFE5B84A); private val Dim = Color(0xFF8A938A)
private val Mono = FontFamily.Monospace

private fun fmt(b: Long) = if (b >= 1048576) "%.1f MB".format(b / 1048576.0) else "${b / 1024} KB"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Bg, surface = Card)) {
                Surface(color = Bg, modifier = Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { ConfigStore(ctx) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (android.os.Build.VERSION.SDK_INT >= 33) notif.launch(android.Manifest.permission.POST_NOTIFICATIONS) }
    var tab by remember { mutableIntStateOf(0) }
    var configs by remember { mutableStateOf(store.configs()) }
    var selected by remember { mutableStateOf(store.selected()) }
    fun refresh() { configs = store.configs(); selected = store.selected() }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Column(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("D Y L A N   V P N", color = Green, fontFamily = Mono, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("v1.0.0", color = Dim, fontFamily = Mono, fontSize = 12.sp)
        }
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> HomeScreen(store, selected) { refresh() }
                1 -> ConfigsScreen(store, configs, selected) { refresh() }
                2 -> LogsScreen()
                else -> MoreScreen(store)
            }
        }
        NavigationBar(containerColor = Card) {
            listOf("HOME" to Icons.Filled.Home, "CONFIGS" to Icons.Filled.Cloud, "LOGS" to Icons.Filled.Info, "MORE" to Icons.Filled.MoreHoriz)
                .forEachIndexed { i, (l, ic) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, l) }, label = { Text(l, fontSize = 11.sp) })
                }
        }
    }
}

@Composable
fun HomeScreen(store: ConfigStore, cfg: VpnConfig?, onChange: () -> Unit) {
    val ctx = LocalContext.current
    val connected by VpnState.connected.collectAsState()
    val connecting by VpnState.connecting.collectAsState()
    val down by VpnState.down.collectAsState(); val up by VpnState.up.collectAsState()
    val ping by VpnState.ping.collectAsState()
    val scope = rememberCoroutineScope()

    fun startService() { ctx.startForegroundService(Intent(ctx, DylanVpnService::class.java)) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == android.app.Activity.RESULT_OK) startService()
    }
    fun toggle() {
        if (connected || connecting) { ctx.startService(Intent(ctx, DylanVpnService::class.java).setAction(DylanVpnService.ACTION_STOP)); return }
        if (cfg == null) { LogBus.log("Ajoute une configuration d'abord."); return }
        val i = VpnService.prepare(ctx); if (i != null) perm.launch(i) else startService()
    }
    val col = if (connected) Green else Dim
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        Box(Modifier.size(170.dp).clip(CircleShape).background(Card).border(BorderStroke(2.dp, col), CircleShape).clickable { toggle() },
            contentAlignment = Alignment.Center) { Icon(Icons.Filled.PowerSettingsNew, null, tint = col, modifier = Modifier.size(80.dp)) }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card).border(BorderStroke(1.dp, col), RoundedCornerShape(12.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(if (connected) Icons.Filled.CheckCircle else Icons.Filled.Cancel, null, tint = col, modifier = Modifier.size(36.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(if (connected) "CONNECTED" else if (connecting) "CONNECTING…" else "DISCONNECTED", color = col, fontFamily = Mono, fontWeight = FontWeight.Bold)
                Text(if (connected) "Traffic is flowing through the tunnel." else "Tap the button to connect.", color = Dim, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card).padding(16.dp)) {
            Text("ACTIVE CONFIGURATION", color = Dim, fontFamily = Mono, fontSize = 12.sp)
            Text(cfg?.name ?: "—", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("${cfg?.protocol ?: ""}   Ping ${if (ping >= 0) "${ping}ms" else "—"}", color = Gold, fontFamily = Mono)
            OutlinedButton(onClick = { scope.launch {
                VpnState.ping.value = withContext(Dispatchers.IO) {
                    if (connected) CoreBridge.delay().toInt() else cfg?.let { ConfigParser.tcpPing(it) } ?: -1
                } } }, border = BorderStroke(1.dp, Green), modifier = Modifier.fillMaxWidth()) { Text("PING", color = Green, fontFamily = Mono, fontWeight = FontWeight.Bold) }
            HorizontalDivider(color = Dim.copy(alpha = .3f))
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Text("↓ ${fmt(down)}", color = Green, fontFamily = Mono)
                Text("↑ ${fmt(up)}", color = Gold, fontFamily = Mono)
            }
        }
    }
}

@Composable
fun ConfigsScreen(store: ConfigStore, configs: List<VpnConfig>, sel: VpnConfig?, onChange: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val pings = remember { mutableStateMapOf<String, Int>() }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(configs) { c ->
                val on = sel?.link == c.link
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (on) Color(0xFF06301A) else Card)
                    .border(BorderStroke(if (on) 2.dp else 1.dp, if (on) Green else Dim.copy(alpha = .3f)), RoundedCornerShape(10.dp))
                    .clickable { store.select(c.link); onChange() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.name, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${c.protocol}  ${c.host}:${c.port}", color = Dim, fontFamily = Mono, fontSize = 12.sp)
                        Text("Ping ${pings[c.link]?.takeIf { it >= 0 }?.let { "${it}ms" } ?: "—"}", color = Gold, fontFamily = Mono, fontSize = 12.sp)
                    }
                    IconButton({ scope.launch { pings[c.link] = withContext(Dispatchers.IO) { ConfigParser.tcpPing(c) } } }) { Icon(Icons.Filled.Speed, null, tint = Green) }
                    IconButton({ store.remove(c.link); onChange() }) { Icon(Icons.Filled.Delete, null, tint = Dim) }
                }
            }
        }
        FloatingActionButton(onClick = {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val txt = cm.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
            val n = txt.lines().count { it.isNotBlank() && store.add(it) }
            LogBus.log(if (n > 0) "$n configuration(s) importée(s)." else "Presse-papiers : aucun lien vmess/vless/trojan/ss valide.")
            onChange()
        }, containerColor = Green, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) { Icon(Icons.Filled.Add, "Importer depuis le presse-papiers") }
    }
}

@Composable
fun LogsScreen() {
    val lines by LogBus.lines.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { IconButton({ LogBus.clear() }) { Icon(Icons.Filled.Delete, null, tint = Dim) } }
        LazyColumn { items(lines) { Text(it, color = Dim, fontFamily = Mono, fontSize = 13.sp, modifier = Modifier.padding(vertical = 6.dp)) } }
    }
}

@Composable
fun MoreScreen(store: ConfigStore) {
    val ctx = LocalContext.current
    var perApp by remember { mutableStateOf(false) }
    if (perApp) { PerAppScreen(store) { perApp = false }; return }
    @Composable fun Item(icon: androidx.compose.ui.graphics.vector.ImageVector, t: String, d: String, f: () -> Unit) =
        Row(Modifier.fillMaxWidth().clickable { f() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Green); Spacer(Modifier.width(16.dp))
            Column { Text(t, color = Color.White, fontWeight = FontWeight.Bold); Text(d, color = Dim, fontSize = 13.sp) }
        }
    Column(Modifier.fillMaxSize()) {
        Item(Icons.Filled.Apps, "Per-app Proxy", "Choose which apps are tunneled through the VPN.") { perApp = true }
        Item(Icons.Filled.BatteryChargingFull, "Battery optimisation", "Allow DYLAN VPN to keep the tunnel alive in the background.") {
            ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
        }
        Item(Icons.Filled.VpnKey, "System VPN profiles", "Open Android's VPN settings to inspect or remove a stuck VPN profile.") {
            ctx.startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
        }
        Item(Icons.Filled.Info, "Version Info", "DYLAN VPN 1.0.0") {}
    }
}

@Composable
fun PerAppScreen(store: ConfigStore, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val apps = remember {
        val pm = ctx.packageManager
        pm.getInstalledApplications(0).filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }.map { pm.getApplicationLabel(it).toString() to it.packageName }
    }
    var allowed by remember { mutableStateOf(store.allowedApps()) }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, null, tint = Green) }
            Text("Per-app Proxy (vide = toutes les apps)", color = Color.White)
        }
        LazyColumn {
            items(apps) { (label, pkg) ->
                Row(Modifier.fillMaxWidth().clickable {
                    allowed = if (pkg in allowed) allowed - pkg else allowed + pkg; store.setAllowedApps(allowed)
                }.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(pkg in allowed, null); Spacer(Modifier.width(12.dp))
                    Column { Text(label, color = Color.White); Text(pkg, color = Dim, fontSize = 11.sp) }
                }
            }
        }
    }
}
