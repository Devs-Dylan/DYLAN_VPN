package com.dylan.vpn

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URI
import java.net.URLDecoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class VpnConfig(val name: String, val link: String, val protocol: String, val host: String, val port: Int, val ping: Int = -1)

object VpnState {
    val connected = MutableStateFlow(false)
    val connecting = MutableStateFlow(false)
    val down = MutableStateFlow(0L)
    val up = MutableStateFlow(0L)
}

object LogBus {
    val lines = MutableStateFlow<List<String>>(emptyList())
    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        lines.value = listOf("$t  > $msg") + lines.value.take(199)
    }
    fun clear() { lines.value = emptyList() }
}

object ConfigParser {
    private fun q(uri: URI): Map<String, String> = (uri.rawQuery ?: "").split("&").filter { it.contains("=") }
        .associate { it.substringBefore("=") to URLDecoder.decode(it.substringAfter("="), "UTF-8") }
    private fun b64(s: String) = String(Base64.decode(s.trim(), Base64.DEFAULT or Base64.URL_SAFE))

    fun parse(raw: String): VpnConfig? = try {
        val link = raw.trim()
        when {
            link.startsWith("vmess://") -> {
                val j = JSONObject(b64(link.removePrefix("vmess://")))
                VpnConfig(j.optString("ps", "vmess"), link, "vmess", j.getString("add"), j.get("port").toString().toInt())
            }
            link.startsWith("vless://") || link.startsWith("trojan://") -> {
                val u = URI(link)
                VpnConfig(URLDecoder.decode(u.rawFragment ?: u.host, "UTF-8"), link, link.substringBefore("://"), u.host, u.port)
            }
            link.startsWith("ss://") -> {
                val (h, p, _, _) = ssParts(link)
                val name = URLDecoder.decode(link.substringAfter("#", h), "UTF-8")
                VpnConfig(name, link, "ss", h as String, p as Int)
            }
            else -> null
        }
    } catch (e: Exception) { null }

    private fun ssParts(link: String): List<Any> {
        val body = link.removePrefix("ss://").substringBefore("#")
        val full = if (body.contains("@")) {
            val (ui, hp) = body.split("@", limit = 2)
            (if (ui.contains(":")) ui else b64(ui)) + "@" + hp
        } else b64(body)
        val (mp, hp) = full.split("@", limit = 2)
        return listOf(hp.substringBeforeLast(":"), hp.substringAfterLast(":").substringBefore("/").toInt(), mp.substringBefore(":"), mp.substringAfter(":"))
    }

    private fun stream(net: String, sec: String, sni: String, fp: String, path: String, host: String,
                       pbk: String = "", sid: String = "", svc: String = ""): JSONObject {
        val s = JSONObject().put("network", net).put("security", sec)
        if (sec == "tls") s.put("tlsSettings", JSONObject().put("serverName", sni).put("fingerprint", fp.ifEmpty { "chrome" }))
        if (sec == "reality") s.put("realitySettings", JSONObject().put("serverName", sni).put("fingerprint", fp.ifEmpty { "chrome" })
            .put("publicKey", pbk).put("shortId", sid))
        if (net == "ws") s.put("wsSettings", JSONObject().put("path", path).put("headers", JSONObject().put("Host", host)))
        if (net == "grpc") s.put("grpcSettings", JSONObject().put("serviceName", svc))
        return s
    }

    private fun outbound(link: String): JSONObject {
        val o = JSONObject().put("tag", "proxy")
        when {
            link.startsWith("vmess://") -> {
                val j = JSONObject(b64(link.removePrefix("vmess://")))
                o.put("protocol", "vmess").put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject()
                    .put("address", j.getString("add")).put("port", j.get("port").toString().toInt())
                    .put("users", JSONArray().put(JSONObject().put("id", j.getString("id")).put("alterId", j.optInt("aid", 0)).put("security", "auto"))))))
                    .put("streamSettings", stream(j.optString("net", "tcp"), if (j.optString("tls") == "tls") "tls" else "none",
                        j.optString("sni", j.optString("host")), "", j.optString("path", "/"), j.optString("host")))
            }
            link.startsWith("vless://") -> {
                val u = URI(link); val p = q(u)
                o.put("protocol", "vless").put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject()
                    .put("address", u.host).put("port", u.port)
                    .put("users", JSONArray().put(JSONObject().put("id", u.userInfo).put("encryption", p["encryption"] ?: "none").put("flow", p["flow"] ?: ""))))))
                    .put("streamSettings", stream(p["type"] ?: "tcp", p["security"] ?: "none", p["sni"] ?: "", p["fp"] ?: "",
                        p["path"] ?: "/", p["host"] ?: "", p["pbk"] ?: "", p["sid"] ?: "", p["serviceName"] ?: ""))
            }
            link.startsWith("trojan://") -> {
                val u = URI(link); val p = q(u)
                o.put("protocol", "trojan").put("settings", JSONObject().put("servers", JSONArray().put(JSONObject()
                    .put("address", u.host).put("port", u.port).put("password", u.userInfo))))
                    .put("streamSettings", stream(p["type"] ?: "tcp", p["security"] ?: "tls", p["sni"] ?: u.host, p["fp"] ?: "",
                        p["path"] ?: "/", p["host"] ?: "", "", "", p["serviceName"] ?: ""))
            }
            link.startsWith("ss://") -> {
                val (h, port, m, pw) = ssParts(link)
                o.put("protocol", "shadowsocks").put("settings", JSONObject().put("servers", JSONArray().put(JSONObject()
                    .put("address", h).put("port", port).put("method", m).put("password", pw))))
            }
            else -> error("Protocole non supporté")
        }
        return o
    }

    /** Config Xray complète : inbound SOCKS local 127.0.0.1:10808 + outbound du lien. */
    fun toXrayJson(link: String): String = JSONObject()
        .put("log", JSONObject().put("loglevel", "warning"))
        .put("inbounds", JSONArray().put(JSONObject().put("tag", "socks").put("port", 10808).put("listen", "127.0.0.1")
            .put("protocol", "socks").put("settings", JSONObject().put("udp", true))
            .put("sniffing", JSONObject().put("enabled", true).put("destOverride", JSONArray().put("http").put("tls")))))
        .put("outbounds", JSONArray().put(outbound(link)).put(JSONObject().put("tag", "direct").put("protocol", "freedom")))
        .toString()

    fun tcpPing(c: VpnConfig): Int = try {
        val t = System.currentTimeMillis()
        Socket().use { it.connect(InetSocketAddress(c.host, c.port), 4000) }
        (System.currentTimeMillis() - t).toInt()
    } catch (e: Exception) { -1 }
}

class ConfigStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("dylan_vpn", Context.MODE_PRIVATE)
    fun links(): List<String> = JSONArray(sp.getString("links", "[]")).let { a -> (0 until a.length()).map { a.getString(it) } }
    private fun saveLinks(l: List<String>) = sp.edit().putString("links", JSONArray(l).toString()).apply()
    fun configs(): List<VpnConfig> = links().mapNotNull { ConfigParser.parse(it) }
    fun add(link: String): Boolean { if (ConfigParser.parse(link) == null) return false; saveLinks((links() + link.trim()).distinct()); return true }
    fun remove(link: String) { saveLinks(links() - link); if (selected()?.link == link) sp.edit().remove("sel").apply() }
    fun select(link: String) = sp.edit().putString("sel", link).apply()
    fun selected(): VpnConfig? = (sp.getString("sel", null) ?: links().firstOrNull())?.let { ConfigParser.parse(it) }
    fun allowedApps(): Set<String> = sp.getStringSet("apps", emptySet()) ?: emptySet()
    fun setAllowedApps(s: Set<String>) = sp.edit().putStringSet("apps", s).apply()
}
