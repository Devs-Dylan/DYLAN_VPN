package com.dylan.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

/**
 * Pont vers le noyau Xray (libv2ray.aar) + tun2socks.
 * Voir README « Brancher le noyau » : c'est ici qu'on lance Xray avec [json]
 * (SOCKS 127.0.0.1:10808) puis qu'on relie [tun] à ce SOCKS via tun2socks.
 */
object CoreBridge {
    fun start(service: VpnService, tun: ParcelFileDescriptor, json: String) {
        LogBus.log("Config Xray générée (${json.length} octets).")
        // TODO: Libv2ray.newV2RayPoint(...).runLoop() puis tun2socks(tun.fd -> 127.0.0.1:10808)
    }
    fun stop() { /* TODO: stopLoop() + arrêt tun2socks */ }
}

class DylanVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopVpn(); return START_NOT_STICKY }
        startVpn(); return START_STICKY
    }

    private fun startVpn() {
        val store = ConfigStore(this)
        val cfg = store.selected() ?: run { LogBus.log("Aucune configuration sélectionnée."); stopSelf(); return }
        VpnState.connecting.value = true
        LogBus.log("Connecting…")
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vpn", "DYLAN VPN", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "vpn").setContentTitle("DYLAN VPN").setContentText(cfg.name)
            .setSmallIcon(android.R.drawable.ic_lock_lock).build())
        try {
            val b = Builder().setSession("DYLAN VPN").setMtu(1500).addAddress("10.10.14.1", 30)
                .addRoute("0.0.0.0", 0).addDnsServer("1.1.1.1").addDnsServer("8.8.8.8")
            val apps = store.allowedApps()
            if (apps.isNotEmpty()) apps.forEach { runCatching { b.addAllowedApplication(it) } }
            else runCatching { b.addDisallowedApplication(packageName) }
            tun = b.establish() ?: error("VPN refusé")
            CoreBridge.start(this, tun!!, ConfigParser.toXrayJson(cfg.link))
            VpnState.connected.value = true
            LogBus.log("Connection verified — traffic is flowing through the tunnel.")
        } catch (e: Exception) {
            LogBus.log("Erreur: ${e.message}"); stopVpn()
        } finally { VpnState.connecting.value = false }
    }

    private fun stopVpn() {
        CoreBridge.stop(); tun?.close(); tun = null
        VpnState.connected.value = false
        LogBus.log("Disconnected.")
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onRevoke() { stopVpn() }
    companion object { const val ACTION_STOP = "com.dylan.vpn.STOP" }
}
