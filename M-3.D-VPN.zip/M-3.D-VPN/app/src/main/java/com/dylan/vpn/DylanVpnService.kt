package com.dylan.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.net.TrafficStats
import android.os.ParcelFileDescriptor
import android.os.Process
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

object CoreBridge {
    @Volatile var controller: CoreController? = null
    private var inited = false

    fun start(service: VpnService, tun: ParcelFileDescriptor, json: String) {
        if (!inited) { Libv2ray.initCoreEnv(service.filesDir.absolutePath, ""); inited = true }
        val handler = object : CoreCallbackHandler {
            override fun startup(): Long { LogBus.log("Core started."); return 0 }
            override fun shutdown(): Long { LogBus.log("Core stopped."); return 0 }
            override fun onEmitStatus(l: Long, s: String?): Long { if (!s.isNullOrBlank()) LogBus.log(s); return 0 }
        }
        val c = Libv2ray.newCoreController(handler)
        c.startLoop(json, tun.fd)
        controller = c
    }

    fun stop() { runCatching { controller?.stopLoop() }; controller = null }

    /** Délai réel (ms) à travers le tunnel, -1 si échec. */
    fun delay(url: String = "https://www.gstatic.com/generate_204"): Long =
        try { controller?.measureDelay(url) ?: -1L } catch (e: Exception) { -1L }
}

class DylanVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopVpn(); return START_NOT_STICKY }
        startVpn(); return START_STICKY
    }

    private fun startVpn() {
        val store = ConfigStore(this)
        val cfg = store.selected() ?: run { LogBus.log("Aucune configuration sélectionnée."); stopSelf(); return }
        VpnState.connecting.value = true
        LogBus.log("Connecting…")
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vpn", "DYLAN VPN", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "vpn").setContentTitle("DYLAN VPN").setContentText(cfg.name)
            .setSmallIcon(android.R.drawable.ic_lock_lock).build())
        Thread {
            try {
                val b = Builder().setSession("DYLAN VPN").setMtu(1500).addAddress("10.10.14.1", 30)
                    .addRoute("0.0.0.0", 0).addDnsServer("1.1.1.1").addDnsServer("8.8.8.8")
                val apps = store.allowedApps()
                if (apps.isNotEmpty()) apps.forEach { runCatching { b.addAllowedApplication(it) } }
                else runCatching { b.addDisallowedApplication(packageName) }
                tun = b.establish() ?: error("VPN refusé")
                LogBus.log("Preparing the connection…")
                CoreBridge.start(this, tun!!, ConfigParser.toXrayJson(cfg.link))
                VpnState.connected.value = true
                LogBus.log("Checking the connection…")
                val d = CoreBridge.delay()
                VpnState.ping.value = d.toInt()
                if (d >= 0) LogBus.log("Connection verified — traffic is flowing through the tunnel. (${d} ms)")
                else LogBus.log("Connection check failed — the server did not respond through the tunnel. Try another configuration.")
                trackTraffic()
            } catch (e: Throwable) {
                LogBus.log("Erreur: ${e.message}"); stopVpn()
            } finally { VpnState.connecting.value = false }
        }.start()
    }

    /** Débit du tunnel = trafic réseau de l'app (connexion vers le serveur). */
    private fun trackTraffic() {
        val uid = Process.myUid()
        val rx0 = TrafficStats.getUidRxBytes(uid); val tx0 = TrafficStats.getUidTxBytes(uid)
        while (VpnState.connected.value) {
            VpnState.down.value = (TrafficStats.getUidRxBytes(uid) - rx0).coerceAtLeast(0)
            VpnState.up.value = (TrafficStats.getUidTxBytes(uid) - tx0).coerceAtLeast(0)
            Thread.sleep(1000)
        }
    }

    private fun stopVpn() {
        CoreBridge.stop(); runCatching { tun?.close() }; tun = null
        VpnState.connected.value = false
        VpnState.down.value = 0; VpnState.up.value = 0; VpnState.ping.value = -1
        LogBus.log("Disconnected.")
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onRevoke() { stopVpn() }
    companion object { const val ACTION_STOP = "com.dylan.vpn.STOP" }
}
